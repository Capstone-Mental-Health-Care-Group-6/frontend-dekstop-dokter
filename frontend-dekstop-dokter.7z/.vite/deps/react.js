import {
  require_react
} from "./chunk-ZAUFE7H7.js";
import "./chunk-UXIASGQL.js";
export default require_react();
//# sourceMappingURL=react.js.map
