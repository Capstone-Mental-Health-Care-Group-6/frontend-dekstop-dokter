import React from "react";
import Layouts from "../../components/layouts/Layouts";

const Artikel = () => {
  return (
    <Layouts>
      <div>Artikel</div>
    </Layouts>
  );
};

export default Artikel;
