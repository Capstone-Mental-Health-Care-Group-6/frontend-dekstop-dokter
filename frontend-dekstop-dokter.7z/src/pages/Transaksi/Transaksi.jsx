import React from "react";
import Layouts from "../../components/layouts/Layouts";

const Transaksi = () => {
  return (
    <Layouts>
      <div>Transaksi</div>
    </Layouts>
  );
};

export default Transaksi;
