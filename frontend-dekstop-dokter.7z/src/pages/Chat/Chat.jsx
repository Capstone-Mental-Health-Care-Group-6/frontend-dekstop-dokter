import React from "react";
import Layouts from "../../components/layouts/Layouts";

const Chat = () => {
  return (
    <Layouts>
      <div>Chat</div>
    </Layouts>
  );
};

export default Chat;
